library(testthat)
library(lucr)

test_check("lucr")
